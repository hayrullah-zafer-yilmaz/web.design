# Credits : coopercodes
This is not my code. i wanted to share it with you as so many people were asking for it.
#
## Download the files and run :
```
npm install
```


## Check out coopercodes github:
<a href="https://github.com/coopercodes/">coopercodes</a>
