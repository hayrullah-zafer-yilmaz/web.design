import React from 'react'

export default function Loader() {
  return (
    <div className="progress-loader">
    <div className="progress"></div>
    </div>

    
  )
}
