document.addEventListener("DOMContentLoaded",function(){
	this.forms[0].addEventListener("change",e => {
		e.target.removeAttribute("class");
	});
});
