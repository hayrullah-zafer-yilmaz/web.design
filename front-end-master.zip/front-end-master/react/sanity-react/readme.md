# Dont forget to ![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99) !

# Installation

install Sanity if you don't have it installed.

``` npm install -g sanity ```

``` npm install @sanity/block-content-to-react ```

Go to <a href="https://sanity.io">sanity.io</a> to create a project. 
