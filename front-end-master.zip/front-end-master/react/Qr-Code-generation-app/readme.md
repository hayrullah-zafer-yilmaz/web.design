Dont forget to ![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99) !
--

# Usage

Nothing special, just download the code and use it. 

No API key Needed. this service is free.

---

Make Sure to check their amazing work <a href="https://goqr.me/">goqr.me/</a>
