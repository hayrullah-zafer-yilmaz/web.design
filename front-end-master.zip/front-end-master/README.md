# Front-end🚀 Don't forget to ![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)

You can find the source code for all the Instagram posts here!

If you want to see previews of these files, follow these steps:

## Step 1
Go to <a href="https://andiicodes.github.io/front-end">andiicodes.github.io/front-end</a>
<br>
<div>
  <img src="ignore/1.jpg" width="500" alt="Step 1">
</div>

## Step 2
Add any folder name that you like after the word "/front-end"
<br>
<div>
  <img src="ignore/2.jpg" width="500" alt="Step 2">
</div>

## Step 3
For example:
Go to <a href="https://andiicodes.github.io/front-end/dropdown-list">andiicodes.github.io/front-end/dropdown-list</a>
<br>
<div>
  <img src="ignore/3.jpg" width="500" alt="Step 3">
</div>


|| check it out on my instagram! @andiicodes , or click this icon > <a href="https://instagram.com/andiicodes" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="andiicodes" height="30" width="40" /></a>
</p>
Telegram : <a href="https://t.me/andiicodes" traget="_blank">@AndiiCodes</a>
