import React from 'react'
import TranslationApp from './TranslationApp'
import "./index.css";

export default function App() {
  return (
    <div>
    <TranslationApp />
    </div>
  )
}
