# Don't forget to ![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)




# Usage
1. SignUp for an RapidAPI account.
2. after finishing the SignUp, Head to this URL to get your API keys
   - <a href="https://rapidapi.com/maatootz/api/instagram-downloader-download-instagram-videos-stories">instagram-downloader on RapidAPI</a>
3. Replace the ```'X-RapidAPI-Key': 'YOUR_RAPID_API_KEYS', ``` inside api.js .
4. Star this repo:)
