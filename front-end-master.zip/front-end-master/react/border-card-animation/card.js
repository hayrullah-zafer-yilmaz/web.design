// Card.js 
const Card = () => {
  return (
   <>
    <div className="card">
  <div className="card-content">
    <h3>Valuable Info</h3>
    <h1>The worst thing about coding is the dementors</h1>
    <p>I can't stand when I have spent the last 47 minutes adjusting the rgb on my gradient only to have a dementor appear and suck my soul out.</p>
  </div>
</div>
   </>
    
  );
};

export default Card;
