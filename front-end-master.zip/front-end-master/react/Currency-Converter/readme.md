Don't Forget to  ![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)
# Usage
### Step 1: Sign up and Get Your API Key

1. Go to https://exchangeratesapi.io
2. Sign up for a free account.
3. Once you're registered, log in and navigate to the "API Access" section.
4. Generate your API key. Don't worry, it's free! With the free plan, you get 1,000 free API calls.
#   

### Step 2: Install react-dropdown

1. Open your project directory in your terminal.
2. Run the command:
  ```npm i react-dropdown```
3. This will install the react-dropdown package, allowing you to easily create dropdowns in your React app.
#



