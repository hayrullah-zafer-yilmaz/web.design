// js.js 



$('.appearance').click(function() {
  $('body').toggleClass("dark");
  $(this).toggleClass("switch");
});
  
