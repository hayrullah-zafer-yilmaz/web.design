# Don't forget to ![Star Badge](https://img.shields.io/static/v1?label=%F0%9F%8C%9F&message=If%20Useful&style=style=flat&color=BC4E99)

Usage
---

### Installation
You just need to install <a href="https://www.npmjs.com/package/@splinetool/react-spline">@Splinetool/spline-react</a>.

Run the following command in your terminal
```
npm i @splinetool/react-spline
```



---

Check out spline tool for more assets/docs.
<a href="https://spline.design/">@Splinetool</a>.
