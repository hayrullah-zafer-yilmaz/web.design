import React from 'react'

export default function AnnouncementBar() {
  return (
    <div>
    <button type="button">
  <span>Telegram @AndiiCodes</span>
  <span>Telegram @AndiiCodes</span>
</button>

    </div>
  )
}
