      <script src="https://unpkg.co/gsap@3/dist/gsap.min.js"></script>
      <script src="https://unpkg.com/gsap@3/dist/ScrollTrigger.min.js"></script>


don't forget to add these into public/index.html!
